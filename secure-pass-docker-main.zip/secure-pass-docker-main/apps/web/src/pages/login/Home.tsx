import React from 'react';
import Login from '../../components/login/Login';

const Home: React.FC = () => {
  return (
    <Login />
  );
}

export default Home;